//---------------------------------------------------------------------------

#include <vcl.h>
#include "md5.h"
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
        MD5_CTX mdContext;
        int caracter;

        //Buffer que usa el programa para la generacion del MD5
        //Los caracteres que rellena con parte del serial esta lleno con 0xFF para reconocerlo
        char buffer[74]={0x31, 0x42, 0x01, 0x67, 0x03, 0x73, 0x05, 0x66, 0x07, 0x44, 0x09, 0x44, 0x0B, 0x52, 0x0D, 0x70, 0x0F, 0x65, 0x11, 0x20, 0x13, 0x69, 0x02, 0x61, 0x04, 0x6F, 0x06, 0x74, 0x08, 0x56, 0x0A, 0x20, 0x0C, 0x69, 0x0E, 0x70, 0x10, 0x72, 0x12, 0x33, 0x14, 0x30, 0x30, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x42, 0x69, 0x67, 0x61, 0x73, 0x6F, 0x66, 0x74, 0x44, 0x56, 0x44, 0x20, 0x52, 0x69, 0x70, 0x70, 0x65, 0x72, 0x20, 0x33, 0x00};

        //Mascara para la generacion del serial
        char Serial[50] = "????-????-????-????-????-????-????-????";
        char hexa[36] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        AnsiString Datos="";
        AnsiString Aux="";

        //Le indicamos el largo que usa el programa para la creacion del MD5
        unsigned int len = 73;

        //Generamos el primer bloque de 4 caracteres aleatorios
        for(int x=0; x<4; x++)
                Serial[x]=hexa[random(35)];

        //Generamos el segundo bloque de 4 caracteres aleatorios
        for(int x=5; x<9; x++)
                Serial[x]=hexa[random(35)];
        //Generamos el septimo bloque de 4 caracteres aleatorios
        for(int x=30; x<34; x++)
                Serial[x]=hexa[random(35)];
        //Generamos el octavo bloque de 4 caracteres aleatorios
        for(int x=35; x<39; x++)
                Serial[x]=hexa[random(35)];

        for(int x=0, i=43;x<10;x++, i++)
        {
                buffer[i]=Serial[x];
        }

        //Calculamos el MD5 del buffer
        MD5Init (&mdContext);
        MD5Update (&mdContext, buffer, len);
        MD5Final (&mdContext);

        //Metemos el MD5 en la variable Datos
        for (int i=0;i<16;i++){
                Datos = Datos + Aux.sprintf("%02X",mdContext.digest[i]);
        }

        //Rellenamos los bloques 3�, 4�, 5�, y 6� del serial con los generados
        for(int i=1, x=11; x<30; x++)
        {
                if(x%5!=0)
                {
                        Serial[x-1]=Datos[i];
                        i+=2;
                }
        }

        //Obtenemos el caracter 26� bueno
        caracter = (Serial[0] + 0x13 + Serial[1] + Serial[2] + Serial[3] + Serial[5] + Serial[6] + Serial[7] + Serial[8])%0x10;
        Serial[30] = hexa[caracter];
        Edit_Serial->Text=Serial;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
        randomize();        
}
//---------------------------------------------------------------------------

