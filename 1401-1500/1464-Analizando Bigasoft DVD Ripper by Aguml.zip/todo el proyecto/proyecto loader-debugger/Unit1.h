//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "DbgCLS.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TButton *Button_Buscar;
        TEdit *Edit_Serial;
        TDbgCLS *DbgCLS1;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TButton *ButtonGenerar;
        TEdit *EditGenerar;
        TLabel *Label6;
        void __fastcall Button_BuscarClick(TObject *Sender);
        void __fastcall DbgCLS1BreakBP();
        void __fastcall DbgCLS1CreateProcEvent();
        void __fastcall ButtonGenerarClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
