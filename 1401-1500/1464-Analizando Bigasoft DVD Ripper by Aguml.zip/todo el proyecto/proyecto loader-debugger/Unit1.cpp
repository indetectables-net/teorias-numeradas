//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "DbgCLS"
#pragma resource "*.dfm"
TForm1 *Form1;
AnsiString SerialMalo;
AnsiString SerialBueno;

void EliminarRegistro(void);
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button_BuscarClick(TObject *Sender)
{
        SerialMalo="";
        SerialBueno="";
        EliminarRegistro();
        Form1->DbgCLS1->InitDebug(); //Creamos el proceso
        Form1->DbgCLS1->DebugLoop(); //Ejecutamos el Loop para controlar las excepciones
}
//---------------------------------------------------------------------------

void __fastcall TForm1::DbgCLS1BreakBP()
{
        //Funci�n que maneja nuestros BP�s
        switch(DbgCLS1->GetLastAddr()) //Entramos cuando tengamos cargadas las dlls
        {
                case 0x004A5252:
                        if(SerialMalo.Length() == 0)
                        {
                                SerialBueno=DbgCLS1->ReadMemoryStr(DbgCLS1->GetESI(),19);
                                SerialMalo=DbgCLS1->ReadMemoryStr(DbgCLS1->GetEDI()-0xA,0x27);
                        }
                break;

                case 0x004A5254:
                        DbgCLS1->SetFlag('Z');
                break;

                case 0x004A529E:
                        SerialBueno=SerialMalo.SubString(1,0xA)+SerialBueno.SubString(1,19)+SerialMalo.SubString(0x1E,0xA);
                        SerialBueno[31]=DbgCLS1->ReadMemoryB(DbgCLS1->GetEDX()+0x73E53C);
                        DbgCLS1->ClearBP(0x004A529E);
                        DbgCLS1->ClearBP(0x004A5252);
                        DbgCLS1->ClearBP(0x004A5254);
                        Edit_Serial->Text=SerialBueno.SubString(1,39);
                        DbgCLS1->StopDebug();
                        Button_Buscar->Enabled = false;
                break;
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::DbgCLS1CreateProcEvent()
{
        DbgCLS1->SetBP(0x004A5252);
        DbgCLS1->SetBP(0x004A5254);
        DbgCLS1->SetBP(0x004A529E);
}
//---------------------------------------------------------------------------

void EliminarRegistro(void)
{
        HKEY hKey;
        if(RegOpenKeyExA(HKEY_CURRENT_USER, "Software\\Bigasoft\\DVD Ripper", 0, KEY_ALL_ACCESS, &hKey)== ERROR_SUCCESS)
        {
                RegDeleteKey(hKey,"RegInfo");
                RegCloseKey(hKey);
        }
}
void __fastcall TForm1::ButtonGenerarClick(TObject *Sender)
{
        char caracteres[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        SerialMalo="1111-1111-1111-1111-1111-1111-1111-1111";
        for(int x=1; x<=39; x++)
        {
                if(x%5!=0)
                        SerialMalo[x]=caracteres[random(36)];
        }
        EditGenerar->Text=SerialMalo;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
        randomize();
}
//---------------------------------------------------------------------------
