function Color_ScrollBar (base, arrow, face, dlight, darkshadow, highlight, shadow, track) {
	if (base != "") document.body.style.scrollbarBaseColor=base
	if (arrow != "") document.body.style.scrollbarArrowColor=arrow
	if (face != "") document.body.style.scrollbarFaceColor=face
	if (dlight != "") document.body.style.scroll3dLightColor=dlight
	if (darkshadow != "") document.body.style.scrollDarkSahdowColor=darkshadow
	if (highlight != "") document.body.style.scrollHighLightColor=highlight
	if (shadow != "") document.body.style.scrollShadowColor=shadow
	if (track != "") document.body.style.scrollTrackColor=track
}
