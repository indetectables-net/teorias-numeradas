# ===========================================================
# Script plantilla
# utilizando el componente DbgCLSXv109.ocx
# AUTOR: stzwei - CracksLatinos
# FECHA: 21/11/2009
# ===========================================================


#---------------------------------------
# Aqui definimos el manejador de eventos
#---------------------------------------
class EventManager(object):                                                 # Gestor de eventos                                           
    # Evento que se ejecuta cuando se crea el proceso
    #-----------------------------------------------
    def OnCreateProcEvent(self):                                            # Definimos funcion a ejecutar cuando se crea el proceso 
        print 'Entramos en OnCreateProcEvent'                               # muestra entrada a OnBreakBP
        D.LogImports()
        D.StopDebug()
        print 'Abre LogDbg.txt para Info'

 
#--------------------------------------------------------
# Aqui creamos un objeto COM derivado del OCX DbgCLSXv109
#--------------------------------------------------------
import win32com.client
D = win32com.client.DispatchWithEvents("DbgCLSXv109.DbgCLSX",EventManager)  # Creamos objeto COM DbgCLSXv108
# ------------------------------------------
# Aqui hay que poner el ejecutable a depurar
D.ExeName = 'system.exe'                                                    # Definimos el ejecutable a depurar
# ------------------------------------------
print '\n\n',D.ExeName                                                      # Imprimimos nombre del ejecutable
print '====================================================='          
# D.AboutBox()                                                              # muestra About.
D.InitDebug()                                                               # Iniciamos la depuracion                                                                 
D.DebugLoop()                                                               # Bucle de depuracion
raw_input('\nIntro para finalizar la depuracion')
  
