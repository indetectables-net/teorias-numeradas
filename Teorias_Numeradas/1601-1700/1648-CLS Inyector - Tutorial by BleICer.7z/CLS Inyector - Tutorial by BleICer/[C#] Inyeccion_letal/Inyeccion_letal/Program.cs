﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 *  CLS Inyector
 *  Tutorial by BleICer
 * 
 * */


namespace Inyeccion_letal
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Inyeccion letal ...");

            var app = new DumpProcess("crkme1ch");

            Pattern primer_patron = 
                new Pattern(
                    "E8 B9 79 FB FF 35 34 12 00 00 8B 55 FC 81 F2 78 56 00 00 3B C2 75 29",
                    "E8 B9 79 FB FF 35 34 12 00 00 8B 55 FC 81 F2 78 56 00 00 3B C2 74 29"
                );

            app.rwMemory(primer_patron);

            Console.ReadKey();
        }
    }
}

