﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

/*
 *  Inyector code for CLS - Team
 *  Dev by BleICer & Bym24v
 * 
 * */

namespace Inyeccion_letal
{
    class DumpProcess
    {
        const int PROCESS_VM_READ = 0x0010;
        const int PROCESS_VM_WRITE = 0x0020;

        const int PROCESS_VM_OPERATION = 0x0008;


        [DllImport("kernel32.dll")]
        public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll")]
        public static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, long dwSize, ref long lpNumberOfBytesRead);

        [DllImport("Kernel32.Dll")]
        public static extern bool WriteProcessMemory(IntPtr ProcessHandle, IntPtr Address, byte[] Buffer, long Size, ref long BytesRead);

        /*
        [DllImport("kernel32.dll")]
        public static extern int OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);
        
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool CloseHandle(IntPtr hObject);
        */

        private String      app_process_name;
        private int         app_process_id;
        private Process[]   app_process_list;
        private Process     app_process;
        private IntPtr      app_process_handler;
        private IntPtr      app_process_base_address;
        private IntPtr      app_process_mem_size;

        public DumpProcess(String name)
        {
            try
            {
                app_process_name = name;
                app_process_list = Process.GetProcessesByName(app_process_name);
                app_process = app_process_list[0];
                app_process_id = app_process.Id;
                app_process_handler = OpenProcess(PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION , true, app_process_id);
                app_process_base_address = app_process.MainModule.BaseAddress;
                app_process_mem_size = (IntPtr)app_process.MainModule.ModuleMemorySize;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message.ToString());
            }
        }

        internal bool rwMemory(Pattern pattern)
        {
            pattern.ptr_pattern = getPtrPattern(pattern.pattern);
            if (pattern.ptr_pattern == IntPtr.Zero) return false;
            return writeMemory(pattern.ptr_pattern, pattern.pattern_remplace);
        }

        public byte[] getMemoryDump()
        {
            byte[] buff = new byte[(Int64)app_process_mem_size];
            long BytesReaded = 0;
            ReadProcessMemory(
                app_process_handler, 
                app_process_base_address, 
                buff, 
                buff.Length, 
                ref BytesReaded 
            );
            return buff;
        }

        private static bool EqualsBytes(byte[] buff, byte[] pattern)
        {
            int len = pattern.Length;
            for (int i = 0; i < len; i++)
            {
                if (buff[i] != pattern[i])
                    return false;
            }
            return true;
        }

        public IntPtr getPtrPattern(byte[] pattern, IntPtr ptr_initial, IntPtr ptr_final)
        {
            byte[] buffer, match;
            long sizeBytesReaded;
            long p_mem, mem_size, mem_final;


            // buffer for fast seeker
            mem_size = 1000;

            p_mem = (long)ptr_initial;
            mem_final = (long)ptr_final;
            sizeBytesReaded = 0;
            buffer = new byte[mem_size] ;
            match = new byte[pattern.Length];

            
            // fast seeker
            while (p_mem < mem_final)
            {
                ReadProcessMemory
                (
                    app_process_handler, 
                    (IntPtr)p_mem,
                    buffer, 
                    mem_size, 
                    ref sizeBytesReaded
                );

                for (int i = 0; i < mem_size; i++) {
                    if (buffer[i] == pattern[0])
                    {
                        ReadProcessMemory
                        (
                            app_process_handler,
                            (IntPtr)(p_mem + i),
                            match,
                            match.Length,
                            ref sizeBytesReaded
                        );

                        if (EqualsBytes(match, pattern))
                        {
                            Console.WriteLine("Pattern found at: " + (p_mem + i).ToString("X8"));
                            return (IntPtr)p_mem + i;
                        }
                    }
                }
                p_mem += mem_size;
            }
            
            return IntPtr.Zero;
        }

        public IntPtr getPtrPattern(byte[] pattern)
        {
            return getPtrPattern(pattern, app_process_base_address, (IntPtr)(app_process_base_address + app_process.MainModule.ModuleMemorySize));
        }

        public byte[] StringPatternToBytesPattern(String single_pattern)
        {
            String[] tmp = single_pattern.Split(' ');
            byte[] res = new byte[tmp.Length];
            for (int i = 0; i < res.Length; i++)
            {
                res[i] = Convert.ToByte( tmp[i] , 16);
            }
            return res;
        }

        public bool writeMemory(IntPtr address, byte[] pattern)
        {
            long bytes_readed = 0;
            return WriteProcessMemory(app_process_handler, address, pattern, pattern.Length, ref bytes_readed);
        }
        
    }
}
