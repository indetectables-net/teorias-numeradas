﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 *  Inyector code for CLS - Team
 *  Dev by BleICer & Bym24v
 * 
 * */

namespace Inyeccion_letal
{
    class Pattern
    {


        public Pattern( String original_pattern, String new_pattern)
        {
            this.pattern = StringPatternToBytesPattern(original_pattern);
            this.pattern_remplace = StringPatternToBytesPattern(new_pattern);
        }

        public byte[] pattern { get; set; }

        public byte[] pattern_remplace { get; set; }

        public IntPtr ptr_pattern { get; set; }

        public static byte[] StringPatternToBytesPattern(String single_pattern)
        {
            String[] tmp = single_pattern.Split(' ');
            byte[] res = new byte[tmp.Length];
            for (int i = 0; i < res.Length; i++)
            {
                res[i] = Convert.ToByte(tmp[i], 16);
            }
            return res;
        }

    }
}
