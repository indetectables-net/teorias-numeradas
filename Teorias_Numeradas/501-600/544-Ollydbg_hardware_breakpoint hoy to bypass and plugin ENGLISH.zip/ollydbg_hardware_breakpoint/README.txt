Ollydbg Anti Anti Hardware Breakpoint
 Copyright (c) 2005 - Mattwood^FRET - mattwood9@gmail.com - www.pastapolis.info - http://reverseengineering.online.fr/spip/

- *How install it?

set olly_hardware_breakpoint.dll in the ollydbg dir.

And if you want to use the user32.dll global loadlibrary add ravioli.dll in the System32 directory and ravioli.dll to the registery.
else set ravioli.dll in the same dir as olly_hardware_breakpoint.dll.

- * What does this plugin?

http://reverseengineering.online.fr/spip/article.php3?id_article=52

hop hop

- * How to use it?

If the target doesn't use user32.dll :
	When you load a program do a F7 or F8 and in the menu and Force to load the dll.

Else it's good :)

If you wanna remove the hook in ntdll goto the menu and Remove the hook :].

- * Note?

Yep, it's a simple version. I load the dll like a pig :]

Cheers,

Mattwood^FRET