Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(56, 8)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(104, 20)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(107, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Poner alg�n nombre"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Nombre:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 16)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Serial:"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(176, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(72, 24)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Salir"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(256, 70)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Form1"
        Me.Text = "KeyGen WinZip 8.1 SR-1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Dim Contador, Letra As Integer
        Dim Nombre, Parte2, LetraS, Parte1 As String
        Dim Resultado As Decimal
        If TextBox1.Text = "" Then
            Label1.Text = "Poner alg�n nombre�"
            Exit Sub
        End If
        Nombre = TextBox1.Text
        Contador = 0
        Do Until Contador = Len(Nombre)
            Letra = Asc(Mid(Nombre, Contador + 1, 1))
            Letra = Letra * Contador
            Parte2 = Str(CInt(Parte2) + Letra)
            Contador = Contador + 1
        Loop
        Parte2 = Hex(CInt(Parte2))
        Parte2 = Microsoft.VisualBasic.Strings.Right(Parte2, 4)
        Contador = 0
        Do Until Contador = Len(Nombre)
            Contador = Contador + 1
            LetraS = Mid(Nombre, Contador, 1)
            Resultado = Generar(LetraS, Resultado)
        Loop
        If Len(Parte2) < 4 Then
            Do Until Len(Parte2) = 4
                Parte2 = "0" + Parte2
            Loop
        End If
        Resultado = Resultado + 99
        Parte1 = Hex(Resultado)
        Parte1 = Microsoft.VisualBasic.Strings.Right(Parte1, 4)
        Label1.Text = Parte1 + Parte2
    End Sub
    Private Function Generar(ByVal Letra As String, ByVal Valor As Decimal) As Decimal
        Dim Contador, Letra256, Result As Integer
        Dim Temp As Decimal

        Contador = 8
        Letra256 = Asc(Letra) * 256 'Asc saca el valor num�rico de Letra
        Generar = Valor

        Do Until Contador = 0
            Temp = Generar   'MOV ESI,EAX
            Temp = Ajuste(Hex(Temp))
            Temp = Temp Xor Letra256  'XOR ESI,ECX
            Temp = Ajuste4(Hex(Temp))  'Aca usamos nuestra funci�n
            'Usamos Hex para convertir a hexadecimal
            Result = Temp And 32768  'TEST SI,8000
            If Result = 0 Then   'Si JE es tomado
                Generar = Generar * 2  'SHL EAX,1
                Generar = Ajuste(Hex(Generar))
                GoTo Fin   'Va a la etiqueta Fin de m�s abajo
            End If
            Generar = Generar * 2   'ADD EAX,EAX
            Generar = Ajuste(Hex(Generar))
            Generar = Generar Xor 4129  'XOR EAX,DWORD PTR SS:[EBP+10]
Fin:
            Letra256 = Letra256 * 2  'SHL ECX,1
            Contador = Contador - 1  'DEC EDX
        Loop
    End Function
    Private Function Ajuste(ByVal N�mero As String) As Decimal
        If Len(N�mero) > 8 Then
            N�mero = Microsoft.VisualBasic.Strings.Right(N�mero, 8)
        Else
            Do Until Len(N�mero) = 8
                N�mero = "0" + N�mero
            Loop
        End If
        Ajuste = System.Uri.FromHex(Microsoft.VisualBasic.Strings.Right(N�mero, 1))
        Ajuste = Ajuste + System.Uri.FromHex(Mid(N�mero, 7, 1)) * 16
        Ajuste = Ajuste + System.Uri.FromHex(Mid(N�mero, 6, 1)) * 256
        Ajuste = Ajuste + System.Uri.FromHex(Mid(N�mero, 5, 1)) * 4096
        Ajuste = Ajuste + System.Uri.FromHex(Mid(N�mero, 4, 1)) * 65536
        Ajuste = Ajuste + System.Uri.FromHex(Mid(N�mero, 3, 1)) * 1048576
        Ajuste = Ajuste + System.Uri.FromHex(Mid(N�mero, 2, 1)) * 16777216
        If System.Uri.FromHex(Mid(N�mero, 1, 1)) = "1" Then
            Ajuste = Ajuste + 268435456 '268435456 multiplicado por 1
        End If
        If System.Uri.FromHex(Mid(N�mero, 1, 1)) = "2" Then
            Ajuste = Ajuste + 536870912 '268435456 multiplicado por 2
        End If
        If System.Uri.FromHex(Mid(N�mero, 1, 1)) = "3" Then
            Ajuste = Ajuste + 805306368 '268435456 multiplicado por 3
        End If
        If System.Uri.FromHex(Mid(N�mero, 1, 1)) = "4" Then
            Ajuste = Ajuste + 1073741824 '268435456 multiplicado por 4
        End If
        If System.Uri.FromHex(Mid(N�mero, 1, 1)) = "5" Then
            Ajuste = Ajuste + 1342177280 '268435456 multiplicado por 5
        End If
        If System.Uri.FromHex(Mid(N�mero, 1, 1)) = "6" Then
            Ajuste = Ajuste + 1610612736 '268435456 multiplicado por 6
        End If
        If System.Uri.FromHex(Mid(N�mero, 1, 1)) = "7" Then
            Ajuste = Ajuste + 1879048192 '268435456 multiplicado por 7
        End If

    End Function
    Private Function Ajuste4(ByVal N�mero As String) As Decimal
        If Len(N�mero) > 4 Then
            N�mero = Microsoft.VisualBasic.Strings.Right(N�mero, 4)
        Else
            Do Until Len(N�mero) = 4
                N�mero = "0" + N�mero
            Loop
        End If
        Ajuste4 = System.Uri.FromHex(Microsoft.VisualBasic.Strings.Right(N�mero, 1))
        Ajuste4 = Ajuste4 + System.Uri.FromHex(Mid(N�mero, 3, 1)) * 16
        Ajuste4 = Ajuste4 + System.Uri.FromHex(Mid(N�mero, 2, 1)) * 256
        Ajuste4 = Ajuste4 + System.Uri.FromHex(Mid(N�mero, 1, 1)) * 4096
    End Function
End Class
